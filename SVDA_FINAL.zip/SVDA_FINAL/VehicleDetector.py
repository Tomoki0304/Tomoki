import time
import types
import uuid
import cv2 as cv2
from haarcascade import Detector

class DetectorSettings:
     def __init__(self) -> None:
        self.movement_threshold = 0
        self.overlap_threshold = 0.2
        self.stale_time = 5
        self.scale_factor = 1.1
        self.min_neighbors = 2

class VehicleDetector:

    def __init__(self,settings:DetectorSettings, haarModel) -> None:
        # self.vehicleCascade = 'cascadeLindgren30.xml'
        self.settings = settings
        self.vehicleClassifier = Detector(haarModel)
        print(settings.scale_factor)
        # self.tracker = cv2.legacy.MultiTracker_create()
        self.first = True
        self.trackers = list()
        self.vehicleDroppedCallback = list()

    def detect(self, frame: cv2.typing.MatLike) -> tuple[int, cv2.typing.MatLike]:
        grayScale = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # cars = self.vehicleClassifier.detectMultiScale(grayScale, 1.1, 6)
        # cars,scores = self.vehicleClassifier.detectMultiScale3(grayScale, scaleFactor= 1.1,minSize=(100,100),maxSize=(500,500),score_threshold=0.5,overlap_threshold=0.5)
        cars, rejectLevel, levelWeights = self.vehicleClassifier.detectMultiScale3(frame,
                                                                                   scaleFactor=self.settings.scale_factor,
                                                                                   minNeighbors=self.settings.min_neighbors,
                                                                                   minSize=(25, 25),
                                                                                   maxSize=(500, 500),
                                                                                   outputRejectLevels=True)
        # cars,scores = self.vehicleClassifier.detectAndFilter(frame,(25,25),(500,500),1.1,0.5,0.3)

        self.updateTrackers(frame)

        for bbox in cars:
            if (self.isTracked(bbox) == False):
                self.trackers.append(VehicleTracker(self.settings,frame, bbox))
                # cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[0]+bbox[2], bbox[1]+bbox[3]), (0, 0, 255), 2)

        for tracked in self.trackers:
            bbox = tracked.bbox
            cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[0] + bbox[2], bbox[1] + bbox[3]), (255, 0, 0), 2)

        # print("Number Tracked: ", len(self.trackers))

        return (len(self.trackers), frame)

    def isTracked(self, bbox) -> bool:
        for i in range(len(self.trackers)):
            alreadyTracked = self.trackers[i].isSameVehicle(bbox)
            # print(alreadyTracked)
            if (alreadyTracked):
                # print(alreadyTracked)
                return True

        return False

    def updateTrackers(self, frame: cv2.typing.MatLike):
        # print(self.trackers)

        for tracker in self.trackers[:]:
            res = tracker.update(frame)
            if (res == False):
                self.vehicleTrackDropped(tracker)
                self.trackers.remove(tracker)
                # print("Tracker Removed:",)

    def registerVehicleTrackDroppedCallback(self, callback: types.FunctionType):
        self.vehicleDroppedCallback.append(callback)

    def vehicleTrackDropped(self, track: "VehicleTracker"):
        for callback in self.vehicleDroppedCallback:
            callback(track)


class VehicleTracker:
    def __init__(self,settings:DetectorSettings, frame: cv2.typing.MatLike, bbox) -> None:
        self.id = uuid.uuid4()
        self.tracker = cv2.TrackerKCF.create()
        self.tracker.init(frame, bbox)
        self.startTime = time.ctime()
        self.lastUpdateTime = time.time()
        self.bbox = bbox
        self.staleTime = settings.stale_time  # in seconds
        self.movementTreshold = settings.movement_threshold  # in pixels
        self.overlapThreshold = settings.overlap_threshold  # percent of area
        self.lastUpdatePosition = bbox

    def update(self, frame: cv2.typing.MatLike) -> bool:
        res, bbox = self.tracker.update(frame)
        isStale = False
        if ((bbox[0] > self.lastUpdatePosition[0] - self.movementTreshold or bbox[0] < self.lastUpdatePosition[0] + self.movementTreshold)
                and (bbox[1] > self.lastUpdatePosition[1] - self.movementTreshold or bbox[1] < self.lastUpdatePosition[1] + self.movementTreshold)):
            if (time.time() - self.lastUpdateTime >= self.staleTime):
                isStale = True
                #print("isStale")
        else:
            self.lastUpdateTime = time.time()
            self.lastUpdatePosition = bbox
        self.bbox = bbox

        (h, w) = frame.shape[0:2]
        # print(s)
        if (res and not isStale):
            return res
        else:
            self.endTime = time.ctime()
            return False

    def isSameVehicle(self, other):
        topRightX = self.bbox[0] + self.bbox[2]
        topRightY = self.bbox[1]
        bottomLeftX = self.bbox[0]
        bottomLeftY = self.bbox[1] + self.bbox[3]

        otherTopRightX = other[0] + other[2]
        otherTopRightY = other[1]
        otherBottomLeftX = other[0]
        otherBottomLeftY = other[1] + other[3]
        # print("bbbx:" , self.bbox)
        # print("Other:", other)
        isOverlapping = not (topRightX < otherBottomLeftX
                             or bottomLeftX > otherTopRightX
                             or topRightY > otherBottomLeftY
                             or bottomLeftY < otherTopRightY)

        if (isOverlapping):
            area = ((max(bottomLeftX, otherBottomLeftX) - min(topRightX, otherTopRightX)) * (
                        max(topRightY, otherTopRightY) - min(bottomLeftY, otherBottomLeftY)))
            percentOverlap = area / (self.bbox[2] * self.bbox[3])
            if (percentOverlap > self.overlapThreshold):
                return True

        return False