import configparser
import datetime
import sys
import tkinter
import csv
from tkinter.simpledialog import askstring

import customtkinter as ctk
import os
from PIL import Image, ImageTk
from matplotlib.animation import FuncAnimation
import numpy as np
import cv2
import time
from datetime import timedelta
from tkinter import StringVar, Tk, Label, filedialog, messagebox
import matplotlib

from matplotlib.backend_bases import key_press_handler
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from VehicleDetector import DetectorSettings, VehicleDetector

# from tkinterweb import HtmlFrame


IMAGE_PATH = os.path.join(os.path.dirname(__file__), "Assets")
ctk.set_appearance_mode("dark")  # Modes: system (default), light, dark
ctk.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green

program_is_running = False
elapsed_time = 0
video_file = ""
video_url_address = ""
classifier_algorithm = ""
detection_logs = list()
settings_path = 'settings.ini'


global VIDEO_PATH
global test_log
global vehicle_count
global settings


class DetectionLog:
    def __init__(self,id,start,end) -> None:
        self.id = id
        self.start = start
        self.end = end

    def get_record(self):
        return [self.id,self.start,self.end]
    
   
class UISettings:
    def __init__(self) -> None:
        self.data_refresh_rate = 5 #seconds      
        self.elevated_traffic_threshold = 10
        self.high_traffic_threshold = 15    


class Settings:
    def __init__(self) -> None:
        self.ui_settings = UISettings()
        self.detector_settings = DetectorSettings()



class SettingsDialog(ctk.CTkToplevel):
    def __init__(self,*args,**kwargs):

        super().__init__(*args,**kwargs)
        global settings
        self.data_refresh_rate = StringVar(value=settings.ui_settings.data_refresh_rate)
        self.elevated_traffic_threshold = StringVar(value=settings.ui_settings.elevated_traffic_threshold)
        self.high_traffic_threshold = StringVar(value=settings.ui_settings.high_traffic_threshold)

        self.movement_threshold = StringVar(value=settings.detector_settings.movement_threshold)
        self.overlap_threshold = StringVar(value=settings.detector_settings.overlap_threshold)
        self.stale_time = StringVar(value=settings.detector_settings.stale_time)
        self.scale_factor = StringVar(value=settings.detector_settings.scale_factor)
        self.min_neighbors = StringVar(value=settings.detector_settings.min_neighbors)

        int_filter = self.register(self.int_validator)
        float_filter = self.register(self.float_validator)
        
        row = 0
        self.ui_label = ctk.CTkLabel(self,text="UI Settings", font=ctk.CTkFont(family="Montserrat", size=24, weight="bold"))
        self.ui_label.grid(row=row,columnspan = 2)

        row += 1
        #self.geometry("400x300")
        self.data_refresh_label = ctk.CTkLabel(self, text="Graph Refresh Rate(ms)")
        self.data_refresh_label.grid(row = row,column = 0,padx = 10, pady=10)
        self.data_refresh_input = ctk.CTkEntry(self,textvariable=self.data_refresh_rate, validatecommand=(int_filter,'%P'), validate='key')
        self.data_refresh_input.grid(row = row,column = 1)

        row +=1
        self.elevated_threshold_label = ctk.CTkLabel(self, text="Elevated Traffic Threshold(cnt)")
        self.elevated_threshold_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.elevated_threshold_input = ctk.CTkEntry(self, textvariable=self.elevated_traffic_threshold, validatecommand=(int_filter,'%P'), validate='key')
        self.elevated_threshold_input.grid(row = row,column = 1)


        row +=1
        self.high_threshold_label = ctk.CTkLabel(self, text="High Traffic Threshold(cnt)")
        self.high_threshold_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.high_threshold_input = ctk.CTkEntry(self, textvariable=self.high_traffic_threshold, validatecommand=(int_filter,'%P'), validate='key')
        self.high_threshold_input.grid(row = row,column = 1)
        
        row += 1
        self.detector_label = ctk.CTkLabel(self,text="Detector Settings", font=ctk.CTkFont(family="Montserrat", size=24, weight="bold"))
        self.detector_label.grid(row=row,columnspan = 2, pady = (20,5))

        row +=1
        self.movement_threshold_label = ctk.CTkLabel(self, text="Movement threshold(pixels)")
        self.movement_threshold_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.movement_threshold_input = ctk.CTkEntry(self, textvariable=self.movement_threshold, validatecommand=(int_filter,'%P'), validate='key')
        self.movement_threshold_input.grid(row = row,column = 1)

        row +=1
        self.overlap_threshold_label = ctk.CTkLabel(self, text="Overlap Threshold(<1)")
        self.overlap_threshold_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.overlap_threshold_input = ctk.CTkEntry(self, textvariable=self.overlap_threshold, validatecommand=(float_filter,'%P'), validate='key')
        self.overlap_threshold_input.grid(row = row,column = 1)

        row +=1
        self.stale_track_label = ctk.CTkLabel(self, text="Stale Track Timeout(s)")
        self.stale_track_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.stale_track_input = ctk.CTkEntry(self, textvariable=self.stale_time, validatecommand=(int_filter,'%P'), validate='key')
        self.stale_track_input.grid(row = row,column = 1)

        row +=1
        self.scale_factor_label = ctk.CTkLabel(self, text="Scale Factor")
        self.scale_factor_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.scale_factor_input = ctk.CTkEntry(self, textvariable=self.scale_factor, validatecommand=(float_filter,'%P'), validate='key')
        self.scale_factor_input.grid(row = row,column = 1)

        row +=1
        self.min_neighbors_label = ctk.CTkLabel(self, text="Minimum Neighbors(cnt)")
        self.min_neighbors_label.grid(row = row,column = 0,padx = (10,10), pady=10)
        self.min_neighbors_input = ctk.CTkEntry(self, textvariable=self.min_neighbors, validatecommand=(int_filter,'%P'), validate='key')
        self.min_neighbors_input.grid(row = row,column = 1)
    
        self.ok_button = ctk.CTkButton(
            self,
            text="Ok",            
            command=self.ok,            
        )

        self.cancel_button = ctk.CTkButton(
            self,
            text="Cancel",            
            command=self.cancel,            
        )
        row +=1
        self.ok_button.grid(row=row,column = 0, pady=15)
        self.cancel_button.grid(row=row,column=1,pady=15,padx = (0,10))

    def int_validator(self,c):        
        if(str.isdigit(c) or c == ""):
            return True
        else:
            return False
        
    def float_validator(self,c):       
        if(str.isdigit(c) or c == "" or c=='.'):
            return True
        else:
            return False
  
    def cancel(self):
        self.destroy()

    def ok(self):
        global settings
        global settings_path
        settings.ui_settings.data_refresh_rate = int(self.data_refresh_rate.get())
        settings.ui_settings.elevated_traffic_threshold = int(self.elevated_traffic_threshold.get())
        settings.ui_settings.high_traffic_threshold = int(self.high_traffic_threshold.get())

        settings.detector_settings.movement_threshold = int(self.movement_threshold.get())
        settings.detector_settings.overlap_threshold = float(self.overlap_threshold.get())
        settings.detector_settings.stale_time = int(self.stale_time.get())
        settings.detector_settings.scale_factor = float(self.scale_factor.get())
        settings.detector_settings.min_neighbors = int(self.min_neighbors.get())

        config_file = configparser.ConfigParser()
        config_file.read(settings_path)

        config_file.set('ui_settings','data_refresh_rate',self.data_refresh_rate.get())
        config_file.set('ui_settings','elevated_traffic_threshold',self.elevated_traffic_threshold.get())
        config_file.set('ui_settings','high_traffic_threshold',self.high_traffic_threshold.get())

        config_file.set('detector_settings','movement_threshold',self.movement_threshold.get())
        config_file.set('detector_settings','overlap_threshold',self.overlap_threshold.get())
        config_file.set('detector_settings','stale_time',self.stale_time.get())
        config_file.set('detector_settings','scale_factor',self.scale_factor.get())
        config_file.set('detector_settings','min_neighbors',self.min_neighbors.get())

        with open(settings_path,'w') as configsettings:
            config_file.write(configsettings)

        self.destroy()

class TitleFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        

        self.bg_image = ctk.CTkImage(
            Image.open(IMAGE_PATH + "/background.png"), size=(1366, 85)
        )

        self.app_label = ctk.CTkLabel(
            self,
            text="SigPro Vehicle Detection System",
            font=ctk.CTkFont(family="Montserrat", size=35, weight="bold"),
            image=self.bg_image,
        )

        self.app_label.grid(row=0, column=0)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

class CommandFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.settings_dialog = None
        self.video_input_label = ctk.CTkLabel(
            self,
            text="Video Input",
            font=ctk.CTkFont(size=15, weight="bold"),
        )

        # self.video_input_label.place(x=0, y=0)
        self.video_input_label.grid(row=0, column=0)

        self.video_upload_button = ctk.CTkButton(
            self,
            text="Upload Video File",
            command=self.get_video_file,
            width=200,
            font=ctk.CTkFont(weight="bold"),
        )

        self.video_upload_button.grid(row=2, column=0, pady=(0, 5))

        self.url_entry_button = ctk.CTkButton(
            self,
            text="Enter Stream URL",
            command=self.get_url,
            width=200,
            font=ctk.CTkFont(weight="bold"),
        )
        self.url_entry_button.grid(row=4, column=0, pady=(0, 15))

        self.algorithm_label = ctk.CTkLabel(
            self,
            text="Classifier Model",
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        # self.algorithm_label.place(x=0, y=0)
        self.algorithm_label.grid(row=5, column=0, pady=(15, 5))

        self.selected_algorithm_var = ctk.StringVar(value="Haar Cascade Classifier")
        fileList = os.listdir('models')
        if(len(fileList) >0):
            self.selected_algorithm_var.set(fileList[0])
        self.algorithm_optionmenu = ctk.CTkOptionMenu(
            self,
            values=fileList,
            command=self.select_algorithm,
            width=200,
        )
        self.algorithm_optionmenu.grid(row=6, column=0, pady=(0, 15))

        self.elapsed_time_title_label = ctk.CTkLabel(
            self,
            text="Elapsed Time",
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        self.elapsed_time_title_label.grid(row=7, column=0, pady=(15, 5))

        self.elapsed_time_label = ctk.CTkLabel(
            self,
            text="00:00:00",
            font=ctk.CTkFont(size=25, weight="bold"),
            width=200,
            bg_color="#b2d4e8",
            text_color="black",
        )
        self.elapsed_time_label.grid(row=8, column=0)

        self.start_button = ctk.CTkButton(
            self,
            text="Start",
            width=200,
            font=ctk.CTkFont(weight="bold"),
        )
        self.start_button.grid(row=9, column=0, pady=(30, 0))

        self.stop_button = ctk.CTkButton(
            self,
            text="Stop",
            width=200,
            font=ctk.CTkFont(weight="bold"),
        )
        self.stop_button.grid(row=10, column=0, pady=(5, 0))

        self.reset_button = ctk.CTkButton(
            self,
            text="Reset",
            command=self.reset_program,
            width=200,
            font=ctk.CTkFont(weight="bold"),
        )
        self.reset_button.grid(row=11, column=0, pady=(20, 15))

        self.export_label = ctk.CTkLabel(
            self,
            text="Export Log",
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        # self.algorithm_label.place(x=0, y=0)
        self.export_label.grid(row=12, column=0, pady=(20, 5))

        self.export_button = ctk.CTkButton(
            self,
            text="Export",
            command=self.export_log,
            width=200,
            fg_color="red",
            font=ctk.CTkFont(weight="bold"),
        )
        self.export_button.grid(row=13, column=0, pady=(0, 0))

        self.settings_button = ctk.CTkButton(
            self,
            text="Settings",   
            #image=img,
            font=ctk.CTkFont(weight="bold"),
            width=200,
            #height=25,
            fg_color='#505050',
            command=self.open_settings,            
        )

        self.settings_button.grid(row = 14,column=0,pady=(60,5))

    def open_settings(self):
        if(self.settings_dialog is None or not self.settings_dialog.winfo_exists()):
            self.settings_dialog = SettingsDialog(self)
            self.settings_dialog.after(10, self.settings_dialog.lift)#seems to be a bug in the ctk code.
        else:
            self.settings_dialog.focus()

    def update_elapsed_time(self):
        if program_is_running:
            global elapsed_time
            elapsed_time += 1
            hours = elapsed_time // 3600
            minutes = elapsed_time // 60
            seconds = elapsed_time % 60
            elapsed_time_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            self.elapsed_time_label.configure(text=elapsed_time_str)
            self.after(1000, self.update_elapsed_time)

    def start_program(self):
        #global program_is_running
        #program_is_running = True
        self.update_elapsed_time()

    def reset_program(self):
        global elapsed_time
        elapsed_time = 0
        self.elapsed_time_label.configure(text="00:00:00")

    def select_algorithm(self, choice):
        self.selected_algorithm_var.set(choice)

    def get_video_file(self):
        global VIDEO_PATH
        video_file = self.open_video_input_dialog("File")
        VIDEO_PATH = video_file.replace("/", "\\")
        print(VIDEO_PATH)
        return VIDEO_PATH

    def get_url(self):
        global VIDEO_PATH
        video_url_address = self.open_video_input_dialog("URL")
        VIDEO_PATH = video_url_address.replace(" ", "")
        print(VIDEO_PATH)
        return VIDEO_PATH

    def open_video_input_dialog(self, source_type):
        if source_type == "File":
            return filedialog.askopenfilename()
        else:
            dialog = ctk.CTkInputDialog(
                text="Enter Stream URL", title="URL Input Source"
            )
            return dialog.get_input()

    def export_log(self):
        global program_is_running
        global detection_logs
        csv_file = r"NewProcessedDoc.csv"        
        # FileName
        name = askstring('File Name', 'Enter A Name For Your File')
        if name is None:
            return
        
        name += ".csv"
        filename = os.path.dirname(__file__) + "\\" + name      
        with open(name, 'w',newline='') as out_file:
            writer = csv.writer(out_file)
            writer.writerow(('Vehicle Id', 'Start Time', 'End Time'))
            for det in detection_logs:                
                writer.writerow(det.get_record())



class VideoFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        global VIDEO_PATH
        global vehicle_count
        vehicle_count = 0
        self.numberOfVehicles = 0
        #self.vehicleCountLock = Lock()
        self.IMAGE_WIDTH = 560
        self.IMAGE_HEIGHT = 315

        self.video_default_background = ctk.CTkImage(
            Image.open(IMAGE_PATH + "/video_default_background.png"),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )
        
        self.default_background = ctk.CTkLabel(
            self,
            text="",
            font=ctk.CTkFont(
                family="Montserrat",
                size=15,
                weight="bold",
            ),
            image=self.video_default_background,
        )
        self.default_background.place(x=0, y=0, relwidth=1, relheight=1)
        self.label = Label(self)

    def onVehicleTrackDropped(self, tracker: "VehicleDetector"):
        # log data
        global test_log
        global detection_logs

        det = DetectionLog(str(tracker.id), str(tracker.startTime), str(tracker.endTime))
        detection_logs.append(det)

        log_data = [str(tracker.id), str(tracker.startTime), str(tracker.endTime)]
        test_log.insert(1.0,'\t\t' + det.id + '\t\t')
        test_log.insert(1.0, '\t\t' + det.start + '\t\t')
        test_log.insert(1.0, '\t\t' + det.end + '\t\t')
        test_log.insert(1.0, '\n')
  

    def start_program(self):
        print("Program started from video frame")
        self.default_background.pack_forget()
        print("Welcome label removed")        
        print("Label created")
        self.label.place(x=0, y=0, relwidth=1, relheight=1)        
        print("Label placed")     
        print("Cap set to None")

    def play_video(self, video_path, model):
        global settings
        self.detector = VehicleDetector(settings.detector_settings,model)
        self.detector.registerVehicleTrackDroppedCallback(self.onVehicleTrackDropped)
        self.cap = cv2.VideoCapture(video_path)
        if not self.cap.isOpened():
           tkinter.messagebox.showerror(title = 'Error Opening Video',message = 'The video source is not valid.' )
           self.reset_video_frame()
           return False
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.frameTime = 1/self.fps
        print("fps:", self.frameTime)
        self.update_frame()
        return True

    def update_frame(self):
        start_time = time.time()
        ret, frame = self.cap.read()
        if ret and program_is_running:
            frame_width = 600
            frame_height = 350

            resized = cv2.resize(frame, (frame_width, frame_height))

            numTracked,frameWithDetections = self.detector.detect(resized)
            self.useNumberOfVehiclesTracked(numTracked)

            cv2image = cv2.cvtColor(frameWithDetections, cv2.COLOR_BGR2RGBA)
            img = Image.fromarray(cv2image)

            imgtk = ImageTk.PhotoImage(image=img)
            self.label.imgtk = imgtk
            self.label.configure(image=imgtk)
            dt = time.time() - start_time
            #print("Frame Processing Time:", dt)
            delay=1
            if self.frameTime >= dt:
                delay = int((self.frameTime - dt)*1000)
           
            self.after(delay, self.update_frame)  # refresh frame every 10 ms


    def useNumberOfVehiclesTracked(self,numTracked:int):
        global vehicle_count
        vehicle_count = numTracked

    def reset_video_frame(self):        
        self.label.place_forget()
        self.default_background.place(x=0, y=0, relwidth=1, relheight=1)


class GraphFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        global settings
        self.IMAGE_WIDTH = 560
        self.IMAGE_HEIGHT = 315
        self.x_values = list()
        self.y_values =list()
        
        self.graph_default_background = ctk.CTkImage(
            Image.open(IMAGE_PATH + "/graph_default_background.png"),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )

        self.default_background = ctk.CTkLabel(
            self,
            text="",
            font=ctk.CTkFont(
                family="Montserrat",
                size=15,
                weight="bold",
            ),
            image=self.graph_default_background,
        )

        

        self.default_background.place(x=0, y=0, relwidth=1, relheight=1)
        
        size_pixels = (self.cget("width"), self.cget("width"))
        size_inches = self.get_size_inches(size_pixels)
        self.fig = Figure(figsize=size_inches, dpi=100)
        self.fig.autofmt_xdate()
        
        self.plot = self.fig.add_subplot(111)
        self.plot.autoscale(enable=True)      
        self.plot.set_xlabel('Time')
        self.plot.set_ylabel('Vehicle Count')
        self.canvas = FigureCanvasTkAgg(self.fig, self)
        
        self.animationFunc = FuncAnimation(self.fig,self.update_graph,interval=settings.ui_settings.data_refresh_rate)
        
        
        

    def load_graph_background(self):     
        
        self.default_background.pack_forget()        
    
        self.canvas.get_tk_widget().pack(side=ctk.BOTTOM, fill=ctk.BOTH, expand=True)        
        self.canvas.get_tk_widget().pack(side=ctk.TOP, fill=ctk.BOTH, expand=True)
        self.canvas.get_tk_widget().pack_propagate(False)
        self.canvas.draw()
        #self.toolbar.update()

    def plot_graph(self, x, y, title, x_label, y_label):
        self.line.set_ydata(y)
        self.line.set_xdata(x)
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

    def update_graph(self,i):
        global vehicle_count      
        self.x_values.append(datetime.datetime.now())
        self.y_values.append(vehicle_count)
        self.plot.cla()
        self.plot.set_xlabel('Time')
        self.plot.set_ylabel('Vehicle Count')
        self.plot.plot(self.x_values,self.y_values)
        #print("UpdateGraph")

    def start_graph(self):        
        self.load_graph_background()
        #self.update_graph(0)        
        self.animationFunc.event_source.start()
    
    def stop_graph(self):
        self.animationFunc.event_source.stop()
    
    def reset_graph(self):
        self.x_values.clear()
        self.y_values.clear()
        self.canvas.get_tk_widget().pack_forget()
        self.default_background.place(x=0, y=0, relwidth=1, relheight=1)
        self.plot.cla()
        self.plot.set_xlabel('Time')
        self.plot.set_ylabel('Vehicle Count')
        self.plot.plot(self.x_values,self.y_values)

    def get_size_inches(self, size_pixels):
        dpi = 100
        size_inches = size_pixels[0] / dpi, size_pixels[1] / dpi
        print(
            "Graph Widget width: ", size_inches[0], "Graph Widget height", size_inches[1]
        )
        return size_inches


class LogFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.IMAGE_WIDTH = 560
        self.IMAGE_HEIGHT = 315

        self.log_default_background = ctk.CTkImage(
            Image.open(IMAGE_PATH + "/log_default_background.png"),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )

        self.default_background = ctk.CTkLabel(
            self,
            text="",
            font=ctk.CTkFont(
                family="Montserrat",
                size=15,
                weight="bold",
            ),
            image=self.log_default_background,
        )
        self.default_background.place(x=0, y=0, relwidth=1, relheight=1)


class GaugeFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        self.default_gauge = "./Assets/gauge_default_background.png"
        self.current_gauge = "plot/current_figure.png"
        self.updated_gauge = "plot/updated_figure.png"
        
        self.image_index = 0
        self.IMAGE_WIDTH = 440
        self.IMAGE_HEIGHT = 250

        # print(self.img)
        self.default_image = ctk.CTkImage(
            Image.open(self.default_gauge),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )

        self.low_image = ctk.CTkImage(
            Image.open("plot/Low.png"),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
           
        )

        self.elevated_image = ctk.CTkImage(
            Image.open("plot/Elevated.png"),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )

        self.high_image = ctk.CTkImage(
            Image.open("plot/High.png"),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )

        self.gauge_label = ctk.CTkLabel(
            self,
            text="",
            font=ctk.CTkFont(size=15, weight="bold"),
            image=self.default_image,          
        )
        self.gauge_label.place(x=0, y=0, relwidth=1, relheight=1)
        

    def update_image(self):
        image = Image.open(self.current_gauge)
        self.default_image = ctk.CTkImage(
            Image.open(self.current_gauge),
            size=(self.IMAGE_WIDTH, self.IMAGE_HEIGHT),
        )
        self.gauge_label.configure(image=self.gauge_image)
        image.close()

    def reset_gauge_frame(self):
        self.gauge_label.configure(image=self.default_image)

    def start_gauge(self):
        global vehicle_count
        global program_is_running
        global settings
        if(program_is_running):
            if(vehicle_count < settings.ui_settings.elevated_traffic_threshold):
                self.gauge_label.configure(image=self.low_image)
            elif(vehicle_count < settings.ui_settings.high_traffic_threshold):
                self.gauge_label.configure(image=self.elevated_image)
            else:
                self.gauge_label.configure(image=self.high_image)        
        
            self.gauge_label.after(settings.ui_settings.data_refresh_rate,self.start_gauge)


def license_agreement():
    terms = "SigPros Terms of Use"
    texteula = ("By using SigPro software you are agreeing to be bound by the following terms and conditions: "
                "\n- Uploads are not sourced from copyrighted or confidential materials\n- Uploads are sourced from a "
                "consenting party (or parties)\n- Uploads are free from illicit and/or illegal activity\n- Generated "
                "data will not be used for illegal or illicit activity\n- Source code reuse will be credited to SigPros"
                " with proper attribution\nThe SigPros and its software provide an application with vehicle detection"
                " and traffic analysis. The data generated from the analyzed video feed can be used to monitor and "
                "potentially reduce traffic jams. Failure to agree to these terms will prevent the installation from"
                " executing. If at any point after installing the software “you” (the user) disagree with these terms,"
                " you may exit the program window and uninstall the software. Violation of the terms in this document"
                "may result in the removal of the software and a warning from SigPros.\n\n" + terms.center(250)
                + "\n\n-- Terms and Conditions of Use for the SigPros software\nBY OWNING OR USING THIS SOFTWARE, YOU"
                " ACKNOWLEDGE THAT YOU HAVE READ, UNDERSTAND AND AGREE TO BE BOUND BY THESE TERMS AND CONDITIONS."
                "\n- This software is a service made available by SigPros. All software, documentation, information and"
                "/or other materials provided on and through this software (“Content”) may be used solely under the "
                "following terms and conditions (“Terms of Use”).\n- This software may contain other proprietary "
                "notices and copyright information, the terms of which must be observed and followed. The Content on "
                " this software may contain technical inaccuracies or typographical errors and may change or update "
                "without notice. SigPros may also make improvements and/or changes to the Content at any time without "
                "notice.\n- SigPros assumes no responsibility regarding the accuracy of the Content and use of the "
                "Content is at the recipient’s own risk. SigPros provides no assurances that any reported problems with"
                " any Content will be resolved.\n\n-- Intellectual Property Rights\nExcept as otherwise provided, "
                "Content on this software, including all materials posted by the SigPros, is licensed under a Creative "
                "Commons Attribution 3.0 License.\nAll logos and trademarks contained on this Web site are and remain "
                "the property of their respective owners. No licenses or other rights in or to such logos and/or "
                "trademarks are granted. SigPros Trademark Policy can be found by contacting SigPros.\nExcept as "
                "otherwise expressly stated, by providing the Content, neither SigPros nor the Members grant any "
                "licenses to any copyrights, patents or any other intellectual property rights."
                "\n\n--Users Submissions\nUsers are solely responsible for all materials - whether available publicly"
                " or privately - uploaded, posted, e-mailed, transmitted, or otherwise made available on our sites "
                "(“User Content”).  Neither SigPros nor any of its Members shall be liable for any claims arising "
                "out of User Content. You warrant that you have all rights needed to provide the User Content in "
                "accordance with these terms and all applicable laws or regulations. Some other projects that may "
                "be hosted by SigPros may have license terms or Contributor Agreements that are specific to the "
                "Workgroup or project and may require Users to sign an agreement (such as a Contributor Agreement) "
                "assigning and/or licensing rights in submissions made to such Workgroup or project. In all such "
                "cases, and to the extent there is a conflict, those license terms or agreements take precedence "
                "over these Terms of Use. With respect to any User Content not governed by other Workgroup or "
                "project specific terms or agreements, you agree that the following non-exclusive, irrevocable, "
                "royalty-free worldwide licenses shall apply:\n- Code Submissions. User Content in the form of "
                "source or object code will be governed by the BSD License.\n- All Other Submissions. User Content "
                "that is not in the form of source or object code, including but not limited to white papers, "
                "dissertations, articles or other literary works, power point presentations, encyclopedias, "
                "anthologies, wikis, blogs, diagrams, drawings, sketches, photos or other images, audio content, "
                "video content and audiovisual materials, will be governed by the Creative Commons Attribution 3.0.")

    license_boolean = messagebox.askquestion(title="License Agreement", message=texteula)
    print(license_boolean)
    return license_boolean


class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        global video_file
        global video_url_address
        global VIDEO_PATH
        global classifier_algorithm
        global test_log
        global settings
        global settings_path

        settings = Settings()
        config_reader = configparser.RawConfigParser()
        settings_from_file = config_reader.read(settings_path)
        if(settings_from_file is not None and len(settings_from_file) > 0):                    
            settings = Settings()
            settings.ui_settings.data_refresh_rate = int(config_reader.get('ui_settings','data_refresh_rate'))
            settings.ui_settings.elevated_traffic_threshold = int(config_reader.get('ui_settings','elevated_traffic_threshold'))
            settings.ui_settings.high_traffic_threshold = int(config_reader.get('ui_settings','high_traffic_threshold'))
            settings.detector_settings.movement_threshold = int(config_reader.get('detector_settings','movement_threshold'))
            settings.detector_settings.overlap_threshold = float(config_reader.get('detector_settings','overlap_threshold'))
            settings.detector_settings.stale_time = int(config_reader.get('detector_settings','stale_time'))
            settings.detector_settings.scale_factor = float(config_reader.get('detector_settings','scale_factor'))
            settings.detector_settings.min_neighbors =int(config_reader.get('detector_settings','min_neighbors'))

         
        program_is_running = False
        classifier_algorithm = "Haar Cascade Classifier"

        self.geometry("1366x786")
        self.title("SigPro Vehicle Detection System")
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure((1, 2), weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure((1, 2), weight=1)
        self.iconpath = ImageTk.PhotoImage(
            file=os.path.join(IMAGE_PATH, "logo_dark.png")
        )

        self.wm_iconbitmap()
        self.iconphoto(False, self.iconpath)

        if license_agreement() == "yes":
            title_frame = TitleFrame(master=self, height=85)
            title_frame.grid(row=0, column=0, sticky="nsew", columnspan=3)

            command_frame = CommandFrame(master=self)
            command_frame.grid(
                row=1,
                column=0,
                sticky="nsew",
                rowspan=2,
            )

            video_frame = VideoFrame(master=self)

            video_frame.grid(row=1, column=1, padx=(10, 5), pady=(10, 5), sticky="nsew")

            gauge_frame = GaugeFrame(master=self)
            gauge_frame.grid(row=2, column=1, padx=(10, 5), pady=(5, 10), sticky="nsew")

            globals()['test_log'] = tkinter.Text(master=self, width=50, font=("Arial", 8), fg="white",
                                    borderwidth=0, border=0, state="normal", bg="gray17", highlightcolor="white")
            test_log.grid(row=1, column=2, in_=self, padx=(5, 10), pady=(10, 5), sticky="nsew")

            graph_frame = GraphFrame(master=self)
            graph_frame.grid(row=2, column=2, padx=(5, 10), pady=(5, 10), sticky="nsew")

       
            # def video_uploaded_handler(self):
            #     start()

            # def update_image_handler(self):
            #     print("update image command sent to gauge frame")
            #     gauge_frame.update_image()
            #     print("gage frame image returned")
            #     return "break"


            def start(self):
                print("Video uploaded")
                global program_is_running
                program_is_running = True
                video_frame.start_program()
                if (video_frame.play_video(VIDEO_PATH, model="models/"+command_frame.selected_algorithm_var.get())):
                    graph_frame.start_graph()
                    command_frame.start_program()
                    gauge_frame.start_gauge()
                else:
                    program_is_running = False
              
                    


            def stop(self):
                global program_is_running
                graph_frame.stop_graph()
                program_is_running = False


            def reset(self):
                global program_is_running
                global detection_logs
                if(program_is_running):
                    self.stop()
                global test_log
                test_log.delete("1.0","end")
                detection_logs.clear()
                video_frame.reset_video_frame()
                graph_frame.reset_graph()
                command_frame.reset_program()
                gauge_frame.reset_gauge_frame()


            command_frame.video_upload_button.bind("<Button-1>", start)
            command_frame.url_entry_button.bind("<Button-1>", start)
            command_frame.start_button.bind("<Button-1>", start)
            command_frame.reset_button.bind("<Button-1>", reset)
            command_frame.stop_button.bind("<Button-1>", stop)
        else:
            sys.exit()



if __name__ == '__main__':
    App().mainloop()
